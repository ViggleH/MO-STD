x(1) - x(10) are the design geometries;
X and Y are the equation of the lenses;

Front lens:

d1 = (x(1)/2) + x(2);
aEll1 = sqrt(x(4)^2/(1 + x(5)^2));
hFace1 = -d1  + aEll1;

X = hFace1 + aEll1 * cos(theta) 
Y = x(4) * sin(theta)

(theta \in [Pi/2, 3Pi/2])


Conic Rear Lens:

d2 = (x(1)/2) - x(2)
aEll2 = sqrt(x(7)^2/(1 + x(8)^2));
hFace2 = d2 - aEll2;

X = hFace2 + aEll2 * cos(theta)
Y = x(7) * sin(theta)

(theta \in [-Pi/2, Pi])

Poly Rear Lens:
d2 = (x(1)/2) - x(2);
X = -x(10)*1e-16 * Y^8 -x(9)*1e-8 * Y^6 -x(8)*1e-4 * Y^4 - x(7)*1e-2 * Y^2 + d2
(Y \in [-100, 100])



Aspheric Rear Lens
d2 = (x(1)/2) - x(2)
r = x(7)
k = x(8)
A4 = x(9)*1e-6
A6 = x(10)*1e-12
X = -Y^2/(r*(1+sqrt(1 - (1 + k)*Y^2/r^2))) - A4*Y^4 - A6*Y^6 + d2;




